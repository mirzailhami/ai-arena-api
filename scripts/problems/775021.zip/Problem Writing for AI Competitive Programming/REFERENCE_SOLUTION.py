"""
REFERENCE SOLUTION - Rate Limiter Implementation
This is a complete, working solution that passes all tests.
This file is for validation purposes only and should NOT be included in the competitor package.
"""

from config import RateLimiterConfig
import time


class RateLimiter:
    """
    A rate limiter that implements the sliding window counter algorithm.
    """
    
    def __init__(self, config: RateLimiterConfig):
        """
        Initialize the rate limiter with the given configuration.
        
        Args:
            config: RateLimiterConfig object with rate limiting settings
        """
        self.config = config
        # Store client data: {client_id: {'current_window_start': float, 
        #                                   'current_count': int, 
        #                                   'prev_count': int}}
        self.clients = {}
    
    def _get_window_start(self, timestamp: float) -> float:
        """
        Calculate the start time of the window that contains the given timestamp.
        
        Args:
            timestamp: Unix timestamp in seconds
            
        Returns:
            The start time of the window
        """
        window_index = int(timestamp / self.config.window_size_seconds)
        return window_index * self.config.window_size_seconds
    
    def _get_or_create_client_data(self, client_id: str, window_start: float) -> dict:
        """
        Get existing client data or create new entry.
        
        Args:
            client_id: The client identifier
            window_start: The start time of the current window
            
        Returns:
            Dictionary containing client's tracking data
        """
        if client_id not in self.clients:
            self.clients[client_id] = {
                'current_window_start': window_start,
                'current_count': 0,
                'prev_count': 0
            }
        return self.clients[client_id]
    
    def _update_windows(self, client_data: dict, window_start: float) -> None:
        """
        Update window data if we've moved to a new window.
        
        Args:
            client_data: The client's tracking data
            window_start: The start time of the current window
        """
        if client_data['current_window_start'] != window_start:
            # Calculate how many windows we've moved forward
            windows_passed = int((window_start - client_data['current_window_start']) 
                                / self.config.window_size_seconds)
            
            if windows_passed == 1:
                # Moving to the next window - current becomes previous
                client_data['prev_count'] = client_data['current_count']
            else:
                # Moved multiple windows - previous data is too old
                client_data['prev_count'] = 0
            
            client_data['current_count'] = 0
            client_data['current_window_start'] = window_start
    
    def _calculate_weighted_count(self, client_data: dict, timestamp: float) -> float:
        """
        Calculate the weighted request count using sliding window algorithm.
        
        Args:
            client_data: The client's tracking data
            timestamp: Current timestamp
            
        Returns:
            The weighted count of requests
        """
        elapsed = timestamp - client_data['current_window_start']
        elapsed_percentage = elapsed / self.config.window_size_seconds
        
        # Ensure elapsed_percentage is between 0 and 1
        elapsed_percentage = max(0.0, min(1.0, elapsed_percentage))
        
        weighted_count = (client_data['prev_count'] * (1 - elapsed_percentage) + 
                         client_data['current_count'])
        
        return weighted_count
    
    def allow_request(self, client_id: str, timestamp: float = None) -> bool:
        """
        Determine if a request should be allowed.
        
        Args:
            client_id: Unique identifier for the client
            timestamp: Optional Unix timestamp in seconds (uses current time if None)
            
        Returns:
            True if request is allowed, False if rate limit exceeded
        """
        if timestamp is None:
            timestamp = time.time()
        
        window_start = self._get_window_start(timestamp)
        client_data = self._get_or_create_client_data(client_id, window_start)
        
        # Update windows if necessary
        self._update_windows(client_data, window_start)
        
        # Calculate weighted count
        weighted_count = self._calculate_weighted_count(client_data, timestamp)
        
        # Check if request should be allowed
        if weighted_count < self.config.max_requests:
            # Allow the request and record it
            client_data['current_count'] += 1
            return True
        else:
            # Rate limit exceeded
            return False
    
    def get_remaining_requests(self, client_id: str, timestamp: float = None) -> int:
        """
        Get the number of remaining requests for a client.
        
        Args:
            client_id: Unique identifier for the client
            timestamp: Optional Unix timestamp in seconds (uses current time if None)
            
        Returns:
            Number of remaining requests before hitting rate limit
        """
        if timestamp is None:
            timestamp = time.time()
        
        # If client doesn't exist, they have full quota
        if client_id not in self.clients:
            return self.config.max_requests
        
        window_start = self._get_window_start(timestamp)
        client_data = self.clients[client_id]
        
        # Update windows if necessary
        self._update_windows(client_data, window_start)
        
        # Calculate weighted count
        weighted_count = self._calculate_weighted_count(client_data, timestamp)
        
        # Return remaining requests (can't be negative)
        remaining = self.config.max_requests - int(weighted_count)
        return max(0, remaining)
    
    def reset_client(self, client_id: str) -> None:
        """
        Clear all rate limit data for a specific client.
        
        Args:
            client_id: Unique identifier for the client to reset
        """
        if client_id in self.clients:
            del self.clients[client_id]
    
    def get_request_count(self, client_id: str, timestamp: float = None) -> int:
        """
        Get the current request count for a client in the current window.
        
        Args:
            client_id: Unique identifier for the client
            timestamp: Optional Unix timestamp in seconds (uses current time if None)
            
        Returns:
            Current number of requests in the sliding window
        """
        if timestamp is None:
            timestamp = time.time()
        
        # If client doesn't exist, count is 0
        if client_id not in self.clients:
            return 0
        
        window_start = self._get_window_start(timestamp)
        client_data = self.clients[client_id]
        
        # Update windows if necessary
        self._update_windows(client_data, window_start)
        
        # Calculate weighted count
        weighted_count = self._calculate_weighted_count(client_data, timestamp)
        
        return int(weighted_count)
