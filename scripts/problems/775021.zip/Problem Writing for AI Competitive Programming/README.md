# Rate Limiter Challenge - Complete Submission Package

## Challenge Information

**Problem Title:** Rate Limiter Implementation Challenge  
**Difficulty Level:** Medium  
**Language:** Python 3.11  
**Framework:** pytest for testing  
**Algorithm:** Sliding Window Counter

---

## Problem Overview

This challenge requires competitors to implement a rate limiter system using the sliding window counter algorithm. The rate limiter must track API requests per client and enforce configurable rate limits to prevent abuse.

### What Makes This Challenge Interesting

1. **Real-world application** - Rate limiting is used by every major API (GitHub, Twitter, AWS, etc.)
2. **Algorithm complexity** - Sliding window counter is more sophisticated than simple fixed windows
3. **Multiple edge cases** - Requires handling concurrent requests, window transitions, and various timestamp scenarios
4. **Clear testability** - Behavior is deterministic and fully testable with unit tests

---

## Project Structure

```
.
├── Dockerfile                  # Environment setup for Linux
├── requirements.txt            # Python dependencies
├── PROBLEM_STATEMENT.md        # Problem description for competitors
├── ONE_SHOT_PROMPT.md         # Solution prompt for Gemini
├── README.md                   # This file
├── src/
│   ├── __init__.py
│   ├── config.py              # Pre-provided configuration class
│   └── rate_limiter.py        # STUB - Competitors implement this
└── tests/
    ├── __init__.py
    └── test_rate_limiter.py   # Comprehensive test suite
```

---

## Deliverables Checklist

- ✅ **Problem Statement** - See `PROBLEM_STATEMENT.md` (Medium difficulty)
- ✅ **Project Folder** - Complete buildable Python project with stub implementation
- ✅ **Dockerfile** - Ubuntu-based image with Python 3.11 and all dependencies
- ✅ **One-shot Prompt** - See `ONE_SHOT_PROMPT.md`
- ✅ **Build/Test Command** - `python3 -m pytest tests/ -v --tb=short`
- ✅ **Unit Tests** - 60+ test cases covering all scenarios

---

## Build and Test Instructions

### Option 1: Using Docker (Recommended)

```bash
# Build the Docker image
docker build -t rate-limiter-challenge .

# Run the tests
docker run rate-limiter-challenge
```

### Option 2: Local Python Environment

```bash
# Install dependencies
pip install -r requirements.txt

# Run tests
python -m pytest tests/ -v

# Run tests with detailed output
python -m pytest tests/ -v --tb=short

# Run specific test class
python -m pytest tests/test_rate_limiter.py::TestRateLimiterBasic -v
```

---

## How to Solve This Challenge

### Step 1: Read the Problem Statement
Review `PROBLEM_STATEMENT.md` to understand:
- The sliding window counter algorithm
- Required methods and their signatures
- Expected behavior and edge cases

### Step 2: Examine the Project Structure
- `src/config.py` - Pre-provided configuration class (DO NOT MODIFY)
- `src/rate_limiter.py` - Your implementation goes here (currently a stub)
- `tests/test_rate_limiter.py` - Test cases that verify your solution

### Step 3: Implement the Solution
You can either:
- Use the one-shot prompt in `ONE_SHOT_PROMPT.md` with Gemini
- Write your own custom prompts to generate the solution
- Iteratively refine prompts based on test results

### Step 4: Test Your Solution
```bash
python -m pytest tests/ -v
```

Expected output for a correct solution:
```
======================== test session starts ========================
tests/test_rate_limiter.py::TestRateLimiterConfig::test_valid_config PASSED
tests/test_rate_limiter.py::TestRateLimiterBasic::test_first_request_allowed PASSED
...
======================== 60 passed in 0.15s ========================
```

---

## Test Suite Overview

The test suite includes 60+ comprehensive tests organized into these categories:

### 1. Configuration Tests (4 tests)
- Valid configuration creation
- Invalid parameter validation
- Cleanup settings

### 2. Basic Functionality Tests (5 tests)
- Initialization
- First request handling
- Multiple client tracking
- Rate limit enforcement
- Client reset functionality

### 3. Request Counting Tests (3 tests)
- New client request counts
- Request count increments
- Remaining request calculations

### 4. Sliding Window Algorithm Tests (3 tests)
- Window transitions
- Smooth rate limiting
- Multi-window behavior

### 5. Edge Cases Tests (6 tests)
- Single request limits
- Very small windows
- Large request limits
- Concurrent timestamps
- Empty client IDs
- Special characters in client IDs

### 6. Timestamp Handling Tests (3 tests)
- None timestamp (uses current time)
- Backwards time handling
- Fractional timestamps

### 7. Integration Scenarios (3 tests)
- API rate limiting simulation
- Multiple concurrent users
- Gradual request patterns

### 8. Performance Tests (2 tests)
- Many clients (100+)
- Long-running scenarios

---

## Solution Approach: Sliding Window Counter

The sliding window counter algorithm provides smoother rate limiting than fixed windows:

### Algorithm Explanation

1. **Window Division**: Time is divided into fixed windows of `window_size_seconds`
   
2. **Request Tracking**: For each client, track:
   - Current window: start time and request count
   - Previous window: request count

3. **Weighted Count Calculation**:
   ```
   elapsed_percentage = (current_time % window_size) / window_size
   weighted_count = previous_count * (1 - elapsed_percentage) + current_count
   ```

4. **Decision**: Allow request if `weighted_count < max_requests`

### Example

```
Window size: 60 seconds
Max requests: 10

Timeline:
0s-60s (Window 1): 10 requests at t=0
65s (Window 2): Check new request
  - elapsed_percentage = (65 % 60) / 60 = 5/60 = 0.083
  - weighted_count = 10 * (1 - 0.083) + 0 = 9.17
  - Since 9.17 < 10, request is ALLOWED
```

---

## Scoring Criteria

A solution is evaluated based on:

1. **Compilation/Linting** - Code must be valid Python
2. **Test Pass Rate** - Number of passing tests out of 60+
3. **Correctness** - Proper implementation of sliding window algorithm
4. **Edge Case Handling** - Robust handling of various scenarios

### Score Calculation
- All 60+ tests pass = 100% correct solution
- Partial passes = Proportional score
- Does not compile = 0% score

---

## Reference Implementation

A reference implementation that passes all tests would include:

```python
class RateLimiter:
    def __init__(self, config):
        self.config = config
        self.clients = {}  # {client_id: {current_window_start, current_count, prev_count}}
    
    def _get_window_start(self, timestamp):
        window_index = int(timestamp / self.config.window_size_seconds)
        return window_index * self.config.window_size_seconds
    
    def _update_windows(self, client_data, window_start):
        if client_data['current_window_start'] != window_start:
            # Shift to new window
            client_data['prev_count'] = client_data['current_count']
            client_data['current_count'] = 0
            client_data['current_window_start'] = window_start
    
    def _calculate_weighted_count(self, client_data, timestamp):
        elapsed = timestamp - client_data['current_window_start']
        elapsed_percentage = elapsed / self.config.window_size_seconds
        return (client_data['prev_count'] * (1 - elapsed_percentage) + 
                client_data['current_count'])
    
    # ... implement methods using above helpers
```

---

## Tips for Competitors

1. **Start Simple** - Get basic functionality working first, then handle edge cases
2. **Read Tests** - The test file shows exactly what behavior is expected
3. **Understand the Algorithm** - The sliding window formula is key to correctness
4. **Test Iteratively** - Run tests after each prompt to see what needs fixing
5. **Use Descriptive Prompts** - Explain the algorithm clearly to Gemini

---

## Common Pitfalls

1. **Fixed Window Instead of Sliding** - Must use weighted count, not just current window
2. **Window Transition Logic** - Forgetting to shift current → previous when entering new window
3. **New Client Handling** - Not initializing data structures for first-time clients
4. **Timestamp Handling** - Forgetting to use `time.time()` when timestamp is None
5. **Off-by-One Errors** - Using `<=` instead of `<` in comparisons

---

## Challenge Metadata

**Author:** [Your Name]  
**Date:** 2025-10-23  
**Language:** Python 3.11  
**Testing Framework:** pytest 7.4.0  
**Difficulty:** Medium  
**Estimated Time:** 30-60 minutes  
**Topics:** Rate Limiting, Algorithms, API Design, Distributed Systems

---

## License and Confidentiality

This problem and all associated artifacts are original work and are the intellectual property of Topcoder. All materials are confidential and may not be shared, reproduced, or used outside of the Topcoder platform.

---

## Support and Questions

For questions or issues with this challenge:
1. Review the problem statement carefully
2. Check the test cases for expected behavior
3. Examine the configuration class provided
4. Use the forum for clarification: https://discussions.topcoder.com/discussion/37605/discussion-forum-tab

---

## Build Command Summary

**Docker Build:** `docker build -t rate-limiter-challenge .`  
**Docker Run:** `docker run rate-limiter-challenge`  
**Local Test:** `python3 -m pytest tests/ -v --tb=short`

---

**Good luck with your implementation! 🚀**
