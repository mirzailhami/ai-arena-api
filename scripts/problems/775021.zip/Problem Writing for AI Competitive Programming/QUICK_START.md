# Quick Start Guide

## For Topcoder Team - Integration

### 1. Verify the Package
```bash
cd "Problem Writing for AI Competitive Programming"

# Install dependencies
pip install -r requirements.txt

# Run tests with stub (should see failures)
python -m pytest tests/ -v

# Expected: 14 passed, 15 failed
```

### 2. Test with Docker
```bash
# Build image
docker build -t rate-limiter-challenge .

# Run tests (will show failures with stub)
docker run rate-limiter-challenge

# Expected: 14 passed, 15 failed
```

### 3. Verify Reference Solution
```bash
# Copy reference solution to src
cp REFERENCE_SOLUTION.py src/rate_limiter.py

# Run tests (should all pass)
python -m pytest tests/ -v

# Expected: 29 passed
```

---

## For Competitors - How to Solve

### Step 1: Read the Problem
Open and read `PROBLEM_STATEMENT.md` carefully. Understand:
- The sliding window counter algorithm
- The four methods you need to implement
- The weighted count formula

### Step 2: Explore the Project
Look at these files:
- `src/config.py` - Configuration class (already done, don't modify)
- `src/rate_limiter.py` - Your implementation goes here (currently a stub)
- `tests/test_rate_limiter.py` - Tests that verify your solution

### Step 3: Use the One-Shot Prompt
Open `ONE_SHOT_PROMPT.md` and copy the prompt into Gemini. This should generate a working solution.

Alternatively, write your own prompt describing what you want.

### Step 4: Test Your Solution
```bash
python -m pytest tests/ -v
```

You'll see output like:
```
29 passed in 0.16s          # Perfect!
20 passed, 9 failed         # Getting close
14 passed, 15 failed        # Need more work
```

### Step 5: Iterate
Based on test failures, refine your prompt and regenerate the code.

### Step 6: Submit
When you're satisfied with the test results, submit your solution.

---

## Quick Commands Reference

### Testing
```bash
# Basic test run
python -m pytest tests/

# Verbose output
python -m pytest tests/ -v

# With short error messages
python -m pytest tests/ --tb=short

# Stop on first failure
python -m pytest tests/ -x

# Run specific test class
python -m pytest tests/test_rate_limiter.py::TestRateLimiterBasic -v

# Run specific test
python -m pytest tests/test_rate_limiter.py::TestRateLimiterBasic::test_first_request_allowed -v
```

### Docker
```bash
# Build
docker build -t rate-limiter-challenge .

# Run tests
docker run rate-limiter-challenge

# Build and run
docker build -t rate-limiter-challenge . && docker run rate-limiter-challenge
```

---

## Scoring

Your solution is scored based on test pass rate:
- **29/29 tests pass** = 100% score ✅
- **20/29 tests pass** = ~69% score 
- **14/29 tests pass** = ~48% score (stub level)
- **0/29 tests pass** = 0% score ❌

---

## Troubleshooting

### "No module named pytest"
```bash
pip install pytest pytest-timeout
```

### "Import error for config"
Make sure you're running from the project root directory.

### "All tests passing but I'm using stub"
You might have accidentally replaced the stub with a solution. Restore from `REFERENCE_SOLUTION.py` if needed.

### "Docker build fails"
Make sure Docker is installed and running. Check that you're in the correct directory.

---

## File Structure

```
.
├── PROBLEM_STATEMENT.md       # Problem description (READ THIS FIRST)
├── README.md                   # Complete documentation
├── ONE_SHOT_PROMPT.md         # Solution prompt for Gemini
├── SUBMISSION_SUMMARY.md      # Detailed submission info
├── QUICK_START.md             # This file
├── Dockerfile                  # Docker environment setup
├── requirements.txt            # Python dependencies
├── REFERENCE_SOLUTION.py       # Working solution (for validation)
├── src/
│   ├── __init__.py
│   ├── config.py              # Configuration class (pre-provided)
│   └── rate_limiter.py        # YOUR IMPLEMENTATION HERE
└── tests/
    ├── __init__.py
    └── test_rate_limiter.py   # Test suite (29 tests)
```

---

## Tips for Success

1. **Read the problem carefully** - Understand the sliding window algorithm
2. **Look at the tests** - They show exactly what's expected
3. **Start simple** - Get basic functionality working first
4. **Be specific in prompts** - Explain the algorithm clearly to AI
5. **Test iteratively** - Run tests after each change
6. **Don't give up** - Even partial solutions get partial credit!

---

## Example Prompt (Simple Version)

```
Create a Python class called RateLimiter that tracks API requests per client 
and enforces rate limits using a sliding window counter algorithm.

The class should take a RateLimiterConfig in its constructor and implement:
- allow_request(client_id, timestamp=None) -> bool
- get_remaining_requests(client_id, timestamp=None) -> int  
- reset_client(client_id) -> None
- get_request_count(client_id, timestamp=None) -> int

Use the sliding window formula:
weighted_count = prev_count * (1 - elapsed_percentage) + current_count

Where elapsed_percentage = (timestamp % window_size) / window_size
```

---

Good luck! 🚀
