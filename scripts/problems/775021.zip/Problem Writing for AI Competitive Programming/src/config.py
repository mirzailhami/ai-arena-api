"""
Configuration class for the Rate Limiter.
This file is provided as part of the project - DO NOT MODIFY.
"""

class RateLimiterConfig:
    """
    Configuration for rate limiting behavior.
    
    Attributes:
        max_requests (int): Maximum number of requests allowed per window
        window_size_seconds (int): The time window size in seconds
        enable_cleanup (bool): Whether to automatically clean up old request data
    """
    
    def __init__(self, max_requests: int, window_size_seconds: int, enable_cleanup: bool = True):
        """
        Initialize the rate limiter configuration.
        
        Args:
            max_requests: Maximum number of requests allowed per window
            window_size_seconds: The time window size in seconds
            enable_cleanup: Whether to automatically clean up old data (default: True)
        
        Raises:
            ValueError: If max_requests or window_size_seconds are not positive
        """
        if max_requests <= 0:
            raise ValueError("max_requests must be positive")
        if window_size_seconds <= 0:
            raise ValueError("window_size_seconds must be positive")
            
        self.max_requests = max_requests
        self.window_size_seconds = window_size_seconds
        self.enable_cleanup = enable_cleanup
    
    def __repr__(self):
        return (f"RateLimiterConfig(max_requests={self.max_requests}, "
                f"window_size_seconds={self.window_size_seconds}, "
                f"enable_cleanup={self.enable_cleanup})")
