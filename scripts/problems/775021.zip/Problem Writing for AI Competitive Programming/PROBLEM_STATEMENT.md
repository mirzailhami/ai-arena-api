# Rate Limiter Implementation Challenge

**Difficulty Level:** Medium

## Problem Statement

Your task is to prompt Gemini to generate Python code for a flexible rate limiter system that can protect API endpoints from being overwhelmed by too many requests.

You need to create a class named `RateLimiter` that implements the **Sliding Window Counter** algorithm. This rate limiter should be able to track requests per user/client and enforce configurable rate limits.

### Requirements

Create a `RateLimiter` class in the file `rate_limiter.py` with the following specifications:

#### Constructor
```
RateLimiter(config: RateLimiterConfig)
```
- Takes a `RateLimiterConfig` object that defines the rate limiting rules
- Initializes internal data structures to track requests

#### Methods

1. **`allow_request(client_id: str, timestamp: float = None) -> bool`**
   - Determines if a request from the given client should be allowed
   - `client_id`: A unique identifier for the client making the request (e.g., user ID, API key)
   - `timestamp`: Optional Unix timestamp in seconds (float). If not provided, use current time
   - Returns `True` if the request is allowed, `False` if rate limit is exceeded
   - Should automatically record the request if allowed

2. **`get_remaining_requests(client_id: str, timestamp: float = None) -> int`**
   - Returns how many more requests the client can make in the current window
   - `client_id`: The client identifier to check
   - `timestamp`: Optional Unix timestamp in seconds. If not provided, use current time
   - Returns the number of remaining requests before hitting the rate limit

3. **`reset_client(client_id: str) -> None`**
   - Clears all rate limit data for a specific client
   - Useful for testing or manual resets

4. **`get_request_count(client_id: str, timestamp: float = None) -> int`**
   - Returns the current number of requests made by the client in the current window
   - `client_id`: The client identifier to check
   - `timestamp`: Optional Unix timestamp in seconds. If not provided, use current time

### RateLimiterConfig Specification

The `RateLimiterConfig` class is already provided in the project. It contains:

- **`max_requests`** (int): Maximum number of requests allowed per window
- **`window_size_seconds`** (int): The time window size in seconds
- **`enable_cleanup`** (bool): Whether to automatically clean up old request data (optional, default: True)

### Sliding Window Counter Algorithm

The sliding window counter algorithm works as follows:

1. Divide time into fixed windows (e.g., 60-second windows)
2. For each client, track the number of requests in the current window and previous window
3. When checking if a request should be allowed:
   - Calculate the weighted count based on how far into the current window we are
   - Formula: `weighted_count = previous_window_count * (1 - elapsed_percentage) + current_window_count`
   - Where `elapsed_percentage` = (current_time % window_size) / window_size
4. Allow the request if `weighted_count < max_requests`

### Example Usage

```python
from config import RateLimiterConfig
from rate_limiter import RateLimiter

# Allow 10 requests per minute
config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
limiter = RateLimiter(config)

# First request - should be allowed
allowed = limiter.allow_request("user_123")  # Returns True

# Check remaining requests
remaining = limiter.get_remaining_requests("user_123")  # Returns 9

# Reset a specific client
limiter.reset_client("user_123")
```

### Important Notes

- The `RateLimiterConfig` class is already implemented - you only need to implement `RateLimiter`
- Your implementation should handle concurrent requests gracefully
- Use Python's `time.time()` for getting current timestamps when not provided
- The sliding window algorithm should provide smoother rate limiting than fixed windows
- Consider edge cases like negative timestamps, unknown clients, etc.

### Testing

Your solution will be tested with:
- Various rate limit configurations
- Multiple clients making requests
- Requests at different time intervals
- Edge cases and boundary conditions
- Concurrent request scenarios

The unit tests are comprehensive and will verify that your implementation correctly enforces rate limits using the sliding window counter algorithm.
