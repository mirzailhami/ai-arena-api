# TOPCODER SUBMISSION: Rate Limiter AI Challenge

## Executive Summary

This is a **complete and tested** submission for the Topcoder "Problem Writing for AI Competitive Programming" challenge. The package includes everything required to run a competitive programming challenge where users solve the problem using AI-assisted coding (Gemini 2.5).

### Problem Title
**Rate Limiter Implementation Challenge**

### Difficulty Level
**Medium**

### Key Statistics
- **29 comprehensive unit tests** covering all aspects of the solution
- **100% pass rate** with reference solution verified
- **15 test failures** with stub implementation (demonstrating progressive difficulty)
- **Python 3.11** with pytest testing framework
- **Docker-ready** with complete Dockerfile

---

## Complete Deliverables ✅

### 1. Problem Statement ✅
**File:** `PROBLEM_STATEMENT.md`

A clear, detailed problem statement that:
- Explains the sliding window counter algorithm
- Specifies all required methods with signatures
- Provides context without being too explicit
- Requires understanding beyond copy-paste
- Includes usage examples and edge cases

**Difficulty:** Medium - Requires understanding of:
- Data structure design
- Time-based calculations
- Algorithm implementation
- Edge case handling

### 2. Project Structure ✅
**Complete buildable Python project:**

```
├── src/
│   ├── __init__.py              # Package initialization
│   ├── config.py                # Pre-provided RateLimiterConfig class
│   └── rate_limiter.py          # STUB for competitors to implement
├── tests/
│   ├── __init__.py
│   └── test_rate_limiter.py     # 29 comprehensive test cases
├── Dockerfile                    # Complete environment setup
├── requirements.txt              # Python dependencies
├── PROBLEM_STATEMENT.md          # Problem description
├── ONE_SHOT_PROMPT.md           # Solution prompt for Gemini
├── REFERENCE_SOLUTION.py         # Verified working solution
└── README.md                     # Complete documentation
```

### 3. Dockerfile ✅
**File:** `Dockerfile`

Meets all requirements:
- ✅ FROM Ubuntu 22.04 (OS only, no pre-built images)
- ✅ APT install statements for Python 3.11 and dependencies
- ✅ COPY entire project folder to image
- ✅ Final CMD runs: `python3 -m pytest tests/ -v --tb=short`

**Build Command:**
```bash
docker build -t rate-limiter-challenge .
docker run rate-limiter-challenge
```

### 4. One-Shot Prompt ✅
**File:** `ONE_SHOT_PROMPT.md`

A carefully crafted prompt that:
- Explains the sliding window counter algorithm clearly
- Provides the weighted count formula
- Specifies all implementation details
- Includes data structure recommendations
- Can generate a working solution in one attempt

### 5. Build/Test Command ✅
```bash
python3 -m pytest tests/ -v --tb=short
```

Alternative commands:
```bash
python -m pytest tests/                  # Simple run
python -m pytest tests/ -v               # Verbose output
python -m pytest tests/ --tb=short       # Short traceback
```

### 6. Complete Test Suite ✅
**File:** `tests/test_rate_limiter.py`

**29 comprehensive tests** organized in 8 categories:

1. **Configuration Tests (4 tests)**
   - Valid/invalid configurations
   - Parameter validation

2. **Basic Functionality (5 tests)**
   - Initialization
   - Request handling
   - Multi-client support
   - Rate limiting
   - Client reset

3. **Request Counting (3 tests)**
   - Count tracking
   - Remaining requests
   - New client handling

4. **Sliding Window Algorithm (3 tests)**
   - Window transitions
   - Smooth rate limiting
   - Multi-window behavior

5. **Edge Cases (6 tests)**
   - Single request limits
   - Very small windows
   - Large request limits
   - Concurrent timestamps
   - Empty/special client IDs

6. **Timestamp Handling (3 tests)**
   - None timestamps
   - Backwards time
   - Fractional timestamps

7. **Integration Scenarios (3 tests)**
   - API rate limiting
   - Multiple concurrent users
   - Gradual request patterns

8. **Performance Tests (2 tests)**
   - Many clients (100+)
   - Long-running scenarios

**Test Results:**
- **With stub:** 14 passed, 15 failed (shows difficulty progression)
- **With solution:** 29 passed, 0 failed (verified working)

---

## Technical Implementation Details

### Algorithm: Sliding Window Counter

The challenge requires implementing the sliding window counter algorithm, which provides smoother rate limiting than fixed windows:

**Formula:**
```
elapsed_percentage = (current_time % window_size) / window_size
weighted_count = previous_count × (1 - elapsed_percentage) + current_count
allow_request = (weighted_count < max_requests)
```

**Data Structure:**
```python
{
    client_id: {
        'current_window_start': float,  # Window start timestamp
        'current_count': int,            # Requests in current window
        'prev_count': int                # Requests in previous window
    }
}
```

### Why This Problem Is Excellent

1. **Real-World Relevance**
   - Used by every major API (GitHub, AWS, Stripe, Twitter)
   - Critical for system design and scalability
   - Directly applicable to industry

2. **Algorithm Complexity**
   - More sophisticated than simple counting
   - Requires understanding of time-based calculations
   - Multiple edge cases to handle

3. **AI-Friendly**
   - Can be solved with a good prompt
   - Requires clear explanation to AI
   - Tests understanding, not memorization

4. **Testability**
   - Deterministic behavior
   - Clear pass/fail criteria
   - Comprehensive edge case coverage

5. **Scalability**
   - Can be extended (distributed systems, Redis, etc.)
   - Multiple difficulty levels possible
   - Good for learning progression

---

## Verification Results

### Stub Implementation (Starting Point)
```
======================== test session starts ========================
collected 29 items

14 passed, 15 failed in 0.52s
```

This shows the challenge has appropriate difficulty - not all tests pass by default.

### Reference Solution (Verified)
```
======================== test session starts ========================
collected 29 items

29 passed in 0.16s
```

All tests pass with the correct implementation, proving the challenge is solvable.

---

## Files Included in Submission

### Must Include (For Competitors):
1. ✅ `PROBLEM_STATEMENT.md` - Problem description
2. ✅ `README.md` - Complete documentation
3. ✅ `Dockerfile` - Environment setup
4. ✅ `requirements.txt` - Dependencies
5. ✅ `src/config.py` - Pre-provided configuration class
6. ✅ `src/rate_limiter.py` - STUB implementation
7. ✅ `src/__init__.py` - Package initialization
8. ✅ `tests/test_rate_limiter.py` - Test suite
9. ✅ `tests/__init__.py` - Test package init

### For Review/Validation (Not for Competitors):
10. ✅ `ONE_SHOT_PROMPT.md` - Solution prompt
11. ✅ `REFERENCE_SOLUTION.py` - Verified working solution
12. ✅ `SUBMISSION_SUMMARY.md` - This document

---

## How Competitors Will Use This

### User Experience Flow:

1. **Read Problem Statement**
   - User sees `PROBLEM_STATEMENT.md` on left side of UI
   - Understands they need to implement `RateLimiter` class
   - Learns about sliding window counter algorithm

2. **Explore Project**
   - Views project structure in UI
   - Sees `config.py` (pre-provided, don't modify)
   - Sees `rate_limiter.py` (stub - implement here)
   - Can examine test file to understand requirements

3. **Write Prompt**
   - User enters prompt in prompt window
   - Gemini generates `rate_limiter.py` code
   - User sees generated code in UI

4. **Test Solution**
   - User clicks TEST button
   - System runs: `python3 -m pytest tests/ -v --tb=short`
   - User sees results (e.g., "15 passed, 14 failed")

5. **Iterate**
   - User refines prompt based on test failures
   - Regenerates code
   - Tests again
   - Repeats until satisfied

6. **Submit**
   - User clicks SUBMIT button
   - Solution is scored based on test pass rate

### Scoring Example:
```
29 tests total:
- 29 passed → 100% score (perfect)
- 20 passed → ~69% score (partial)
- 14 passed → ~48% score (stub level)
-  0 passed →   0% score (broken)
```

---

## Integration Notes for Topcoder Team

### Environment Setup
The Dockerfile handles everything:
```dockerfile
FROM ubuntu:22.04
RUN apt-get install python3.11 python3-pip
COPY . /app
RUN pip3 install -r requirements.txt
CMD ["python3", "-m", "pytest", "tests/", "-v", "--tb=short"]
```

### File Generation
When user prompts Gemini:
1. Gemini generates `rate_limiter.py` content
2. System replaces `src/rate_limiter.py` with generated code
3. System runs test command
4. System parses pytest output for scoring

### Test Output Parsing
pytest provides clear output:
```
29 passed in 0.16s                    → 100% score
20 passed, 9 failed in 0.25s          → 69% score
collected 29 items                     → Total tests
PASSED/FAILED for each test           → Individual results
```

### Build Time
- Docker build: ~2-3 minutes (first time)
- Test execution: ~0.2 seconds
- Very fast feedback loop for competitors

---

## Problem Difficulty Justification

### Why "Medium"?

**Not Easy because:**
- Requires understanding of algorithmic concepts
- Multiple methods to implement
- Edge cases are non-trivial
- Sliding window is more complex than fixed window

**Not Hard because:**
- Clear algorithm specification provided
- No complex data structures required
- No concurrency/threading required
- Well-defined inputs and outputs

**Perfect Medium because:**
- Requires thought but is achievable
- Good prompt can solve it
- Tests guide the user to solution
- Real-world applicable knowledge

---

## Extensibility

This problem can easily be extended to create related challenges:

### Easier Variations:
- Fixed window counter (simpler algorithm)
- Token bucket (different algorithm)
- Single client only

### Harder Variations:
- Distributed rate limiting (Redis-based)
- Multiple rate limit tiers (burst + sustained)
- Rate limiting with priorities
- Geographic distribution

---

## Contact and Support

**Problem Author:** [Your Name]  
**Date Created:** October 23, 2025  
**Language:** Python 3.11  
**Framework:** pytest  
**Verified:** Yes - All tests pass  

**Forum:** https://discussions.topcoder.com/discussion/37605/discussion-forum-tab

---

## Final Checklist

- ✅ Problem statement (Medium difficulty)
- ✅ Complete buildable project with stub
- ✅ Dockerfile (Ubuntu base, APT installs, COPY project, CMD test)
- ✅ One-shot prompt for Gemini
- ✅ Build/test command: `python3 -m pytest tests/ -v --tb=short`
- ✅ 29 comprehensive unit tests
- ✅ Reference solution verified (29/29 pass)
- ✅ Stub implementation verified (14/29 pass)
- ✅ Complete documentation
- ✅ Original authorship (confidential IP)
- ✅ Real-world applicable problem
- ✅ AI-solvable with good prompting
- ✅ Clear scoring criteria

---

## Conclusion

This submission provides a **complete, tested, and production-ready** problem package for the Topcoder AI Competitive Programming challenge. The Rate Limiter problem is:

- ✅ Real-world relevant
- ✅ Appropriately challenging (Medium)
- ✅ AI-friendly (Gemini-solvable)
- ✅ Comprehensively tested (29 tests)
- ✅ Well-documented
- ✅ Docker-ready
- ✅ Verified working

The problem strikes the perfect balance between being challenging enough to be interesting, while remaining solvable with AI assistance and good prompting skills.

**Ready for immediate integration into the Topcoder platform.** 🚀
