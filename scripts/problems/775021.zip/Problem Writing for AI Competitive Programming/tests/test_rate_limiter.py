"""
Comprehensive unit tests for the Rate Limiter implementation.
These tests verify the sliding window counter algorithm implementation.
"""

import pytest
import time
import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from config import RateLimiterConfig
from rate_limiter import RateLimiter


class TestRateLimiterConfig:
    """Test the RateLimiterConfig class."""
    
    def test_valid_config(self):
        """Test creating a valid configuration."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        assert config.max_requests == 10
        assert config.window_size_seconds == 60
        assert config.enable_cleanup is True
    
    def test_config_with_cleanup_disabled(self):
        """Test configuration with cleanup disabled."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=30, enable_cleanup=False)
        assert config.max_requests == 5
        assert config.window_size_seconds == 30
        assert config.enable_cleanup is False
    
    def test_invalid_max_requests(self):
        """Test that invalid max_requests raises ValueError."""
        with pytest.raises(ValueError, match="max_requests must be positive"):
            RateLimiterConfig(max_requests=0, window_size_seconds=60)
        
        with pytest.raises(ValueError, match="max_requests must be positive"):
            RateLimiterConfig(max_requests=-1, window_size_seconds=60)
    
    def test_invalid_window_size(self):
        """Test that invalid window_size_seconds raises ValueError."""
        with pytest.raises(ValueError, match="window_size_seconds must be positive"):
            RateLimiterConfig(max_requests=10, window_size_seconds=0)
        
        with pytest.raises(ValueError, match="window_size_seconds must be positive"):
            RateLimiterConfig(max_requests=10, window_size_seconds=-1)


class TestRateLimiterBasic:
    """Basic functionality tests for RateLimiter."""
    
    def test_initialization(self):
        """Test that RateLimiter initializes correctly."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        assert limiter is not None
    
    def test_first_request_allowed(self):
        """Test that the first request is always allowed."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=60)
        limiter = RateLimiter(config)
        assert limiter.allow_request("user1") is True
    
    def test_multiple_clients(self):
        """Test that different clients are tracked independently."""
        config = RateLimiterConfig(max_requests=2, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        assert limiter.allow_request("user1") is True
        assert limiter.allow_request("user2") is True
        assert limiter.allow_request("user1") is True
        assert limiter.allow_request("user2") is True
    
    def test_rate_limit_enforcement(self):
        """Test that rate limits are properly enforced."""
        config = RateLimiterConfig(max_requests=3, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # First 3 requests should be allowed
        assert limiter.allow_request("user1", timestamp) is True
        assert limiter.allow_request("user1", timestamp + 1) is True
        assert limiter.allow_request("user1", timestamp + 2) is True
        
        # 4th request should be blocked
        assert limiter.allow_request("user1", timestamp + 3) is False
    
    def test_reset_client(self):
        """Test that reset_client clears client data."""
        config = RateLimiterConfig(max_requests=2, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # Use up the limit
        assert limiter.allow_request("user1", timestamp) is True
        assert limiter.allow_request("user1", timestamp + 1) is True
        assert limiter.allow_request("user1", timestamp + 2) is False
        
        # Reset and verify we can make requests again
        limiter.reset_client("user1")
        assert limiter.allow_request("user1", timestamp + 3) is True


class TestRateLimiterRequestCount:
    """Test request counting functionality."""
    
    def test_get_request_count_new_client(self):
        """Test that new clients have 0 requests."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        assert limiter.get_request_count("new_user") == 0
    
    def test_get_request_count_after_requests(self):
        """Test that request count increases after requests."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        assert limiter.get_request_count("user1", timestamp) == 0
        limiter.allow_request("user1", timestamp)
        assert limiter.get_request_count("user1", timestamp + 1) >= 1
        limiter.allow_request("user1", timestamp + 2)
        assert limiter.get_request_count("user1", timestamp + 3) >= 2
    
    def test_get_remaining_requests(self):
        """Test getting remaining request count."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # Initially should have full quota
        remaining = limiter.get_remaining_requests("user1", timestamp)
        assert remaining == 5
        
        # After 2 requests
        limiter.allow_request("user1", timestamp)
        limiter.allow_request("user1", timestamp + 1)
        remaining = limiter.get_remaining_requests("user1", timestamp + 2)
        assert remaining == 3
        
        # After hitting limit
        limiter.allow_request("user1", timestamp + 3)
        limiter.allow_request("user1", timestamp + 4)
        limiter.allow_request("user1", timestamp + 5)
        remaining = limiter.get_remaining_requests("user1", timestamp + 6)
        assert remaining == 0


class TestSlidingWindow:
    """Test the sliding window counter algorithm specifically."""
    
    def test_window_transition(self):
        """Test behavior when transitioning between windows."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        # Make 10 requests at the start of a window
        base_time = 1000.0
        for i in range(10):
            assert limiter.allow_request("user1", base_time + i) is True
        
        # 11th request in same window should be blocked
        assert limiter.allow_request("user1", base_time + 10) is False
        
        # After full window passes, should be allowed again
        assert limiter.allow_request("user1", base_time + 61) is True
    
    def test_sliding_window_smooth_transition(self):
        """Test that sliding window provides smooth rate limiting."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Fill up the first window with 10 requests
        for i in range(10):
            assert limiter.allow_request("user1", base_time + i) is True
        
        # Halfway through next window (30 seconds), we should still be limited
        # because sliding window considers previous window
        result = limiter.allow_request("user1", base_time + 30)
        # This might be blocked due to sliding window calculation
        assert result is False or result is True  # Depends on exact implementation
    
    def test_multiple_windows(self):
        """Test behavior across multiple windows."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=10)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Window 1: Use all 5 requests
        for i in range(5):
            assert limiter.allow_request("user1", base_time + i) is True
        assert limiter.allow_request("user1", base_time + 5) is False
        
        # Window 2: After window expires
        for i in range(5):
            assert limiter.allow_request("user1", base_time + 15 + i) is True
        
        # Window 3: After another window
        for i in range(5):
            assert limiter.allow_request("user1", base_time + 30 + i) is True


class TestEdgeCases:
    """Test edge cases and boundary conditions."""
    
    def test_single_request_limit(self):
        """Test with a limit of 1 request per window."""
        config = RateLimiterConfig(max_requests=1, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        assert limiter.allow_request("user1", timestamp) is True
        assert limiter.allow_request("user1", timestamp + 1) is False
        assert limiter.allow_request("user1", timestamp + 61) is True
    
    def test_very_small_window(self):
        """Test with a very small time window."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=1)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # All 5 should succeed in the window
        for i in range(5):
            assert limiter.allow_request("user1", timestamp + i * 0.1) is True
        
        # 6th should fail
        assert limiter.allow_request("user1", timestamp + 0.6) is False
        
        # After 1 second, should succeed again
        assert limiter.allow_request("user1", timestamp + 1.1) is True
    
    def test_large_request_limit(self):
        """Test with a large request limit."""
        config = RateLimiterConfig(max_requests=1000, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # Should allow many requests
        for i in range(100):
            assert limiter.allow_request("user1", timestamp + i * 0.01) is True
        
        remaining = limiter.get_remaining_requests("user1", timestamp + 1)
        assert remaining >= 900
    
    def test_concurrent_timestamps(self):
        """Test multiple requests at the exact same timestamp."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # Make multiple requests at the same timestamp
        for _ in range(5):
            limiter.allow_request("user1", timestamp)
        
        # Next request should be blocked
        assert limiter.allow_request("user1", timestamp) is False
    
    def test_empty_client_id(self):
        """Test with empty string as client_id."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        # Should handle empty string as valid client ID
        assert limiter.allow_request("") is True
    
    def test_special_characters_in_client_id(self):
        """Test client IDs with special characters."""
        config = RateLimiterConfig(max_requests=3, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        special_ids = [
            "user@example.com",
            "user-123-abc",
            "user_with_underscores",
            "user:with:colons",
            "user/with/slashes"
        ]
        
        for client_id in special_ids:
            assert limiter.allow_request(client_id, timestamp) is True


class TestTimestampHandling:
    """Test timestamp-related functionality."""
    
    def test_none_timestamp_uses_current_time(self):
        """Test that None timestamp uses current time."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        # Should not raise an error
        assert limiter.allow_request("user1", None) is True
        assert limiter.allow_request("user1") is True  # Default None
    
    def test_backwards_time(self):
        """Test handling of timestamps that go backwards."""
        config = RateLimiterConfig(max_requests=5, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        # Make requests with increasing timestamps
        assert limiter.allow_request("user1", 1000.0) is True
        assert limiter.allow_request("user1", 1005.0) is True
        
        # Then make a request with an earlier timestamp
        # Should still track correctly
        result = limiter.allow_request("user1", 1003.0)
        assert result is True or result is False  # Implementation dependent
    
    def test_fractional_timestamps(self):
        """Test handling of fractional second timestamps."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=1)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        for i in range(10):
            assert limiter.allow_request("user1", base_time + i * 0.05) is True


class TestIntegrationScenarios:
    """Integration tests with realistic scenarios."""
    
    def test_api_rate_limiting_scenario(self):
        """Simulate API rate limiting with burst traffic."""
        # 100 requests per minute
        config = RateLimiterConfig(max_requests=100, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Burst of 100 requests
        allowed_count = 0
        for i in range(100):
            if limiter.allow_request("api_user", base_time + i * 0.1):
                allowed_count += 1
        
        assert allowed_count == 100
        
        # 101st should be blocked
        assert limiter.allow_request("api_user", base_time + 10) is False
        
        # After window expires, should work again
        assert limiter.allow_request("api_user", base_time + 70) is True
    
    def test_multiple_users_concurrent(self):
        """Test multiple users making requests concurrently."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Simulate 5 users each making requests
        for user_num in range(5):
            user_id = f"user_{user_num}"
            for request_num in range(10):
                timestamp = base_time + request_num
                assert limiter.allow_request(user_id, timestamp) is True
            
            # 11th request should be blocked for each user
            assert limiter.allow_request(user_id, base_time + 10) is False
    
    def test_gradual_request_pattern(self):
        """Test a gradual, steady request pattern."""
        # 10 requests per minute
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Make 10 requests at the start
        for i in range(10):
            timestamp = base_time + i
            assert limiter.allow_request("user1", timestamp) is True
        
        # 11th in same window should be blocked
        assert limiter.allow_request("user1", base_time + 15) is False
        
        # After full window passes, requests should be allowed again
        assert limiter.allow_request("user1", base_time + 65) is True


class TestPerformance:
    """Test performance-related aspects."""
    
    def test_many_clients(self):
        """Test handling many different clients."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        timestamp = 1000.0
        
        # Create 100 different clients
        for i in range(100):
            client_id = f"user_{i}"
            assert limiter.allow_request(client_id, timestamp) is True
            assert limiter.get_request_count(client_id, timestamp + 1) >= 1
    
    def test_long_running_scenario(self):
        """Test behavior over a long time period."""
        config = RateLimiterConfig(max_requests=10, window_size_seconds=60)
        limiter = RateLimiter(config)
        
        base_time = 1000.0
        
        # Simulate requests over 10 windows with clear separation
        for window in range(10):
            window_start = base_time + (window * 120)  # 120 seconds apart (2x window size)
            
            # Make 10 requests in each window
            for i in range(10):
                assert limiter.allow_request("user1", window_start + i) is True
            
            # 11th should be blocked
            assert limiter.allow_request("user1", window_start + 10) is False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
